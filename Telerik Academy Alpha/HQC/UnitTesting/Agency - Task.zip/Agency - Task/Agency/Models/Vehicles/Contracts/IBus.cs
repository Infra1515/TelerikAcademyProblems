﻿namespace Agency.Models.Vehicles.Contracts
{
    public interface IBus : IVehicle
    {

    }
}